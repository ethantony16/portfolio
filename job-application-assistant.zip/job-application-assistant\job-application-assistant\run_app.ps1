$env:GEMINI_API_KEY = "AIzaSyBH0Jpdxf5BhvP8YW1b4ImZGgQurfG03bE"
.\venv\Scripts\python.exe -m uvicorn main:app --reload
