import os
import aiohttp
import json
from fastapi import UploadFile
import docx
from pypdf import PdfReader
import io

from dotenv import load_dotenv

load_dotenv()
# API Key from environment
API_KEY = os.getenv("GEMINI_API_KEY") 

async def extract_text(file: UploadFile) -> str:
    content = await file.read()
    file_obj = io.BytesIO(content)
    text = ""
    
    if file.filename.endswith('.pdf'):
        try:
            reader = PdfReader(file_obj)
            for page in reader.pages:
                text += page.extract_text() + "\n"
        except Exception as e:
            text = f"[Error reading PDF: {e}]"
    elif file.filename.endswith('.docx'):
        try:
            doc = docx.Document(file_obj)
            for para in doc.paragraphs:
                text += para.text + "\n"
        except Exception as e:
            text = f"[Error reading DOCX: {e}]"
    else:
        # Fallback for text files
        try:
            text = content.decode('utf-8')
        except:
            pass
            
    return text

import asyncio
import time

async def generate_content(prompt: str, max_retries: int = 3):
    if not API_KEY or API_KEY == "TODO_ENTER_KEY_HERE":
        return "Error: GEMINI_API_KEY is not set."

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key={API_KEY}"
    headers = {'Content-Type': 'application/json'}

    data = {
        "contents": [{
            "parts": [{"text": prompt}]
        }]
    }

    async with aiohttp.ClientSession() as session:
        for attempt in range(max_retries):
            try:
                async with session.post(url, headers=headers, json=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        try:
                            return result['candidates'][0]['content']['parts'][0]['text']
                        except (KeyError, IndexError):
                            return "Error parsing Gemini response."
                    
                    if response.status == 503:
                        wait_time = (2 ** attempt) + (time.time() % 1) # Exponential backoff + jitter
                        print(f"Gemini overloaded (503). Retrying in {wait_time:.2f}s... (Attempt {attempt + 1}/{max_retries})")
                        await asyncio.sleep(wait_time)
                        continue
                    
                    # Handle other errors
                    text = await response.text()
                    print(f"Error calling Gemini: {response.status} - {text}")
                    return f"Error calling Gemini API: {response.status}"
                    
            except Exception as e:
                 print(f"Exception calling Gemini: {e}")
                 if attempt < max_retries - 1:
                     await asyncio.sleep(1)
                     continue
                 return f"Error: {e}"
        
        return "Error: Gemini remains overloaded after multiple retries. Please try again later."

async def generate_resume_content(job_desc: str, resume_text: str) -> str:
    prompt = f"""
    You are an expert career coach and resume writer.
    
    JOB DESCRIPTION:
    {job_desc}
    
    RESUME:
    {resume_text}
    
    TASK:
    Rewrite the resume to perfectly tailor it to the Job Description. 
    Crucial requirement: You must highlight changes.
    - Wrap ANY new or modified text in <ins> tags (e.g. <ins>New Skill</ins>).
    - Wrap removed text in <del> tags (e.g. <del>Old Irrelevant Skill</del>).
    - Keep the formatting clean and professional. 
    - Output ONLY the body of the resume text. Do not output markdown code blocks.
    """
    return await generate_content(prompt)

async def generate_cover_letter_content(job_desc: str, resume_text: str, cover_letter_text: str) -> str:
    prompt = f"""
    You are an expert career coach.
    
    JOB DESCRIPTION:
    {job_desc}
    
    RESUME:
    {resume_text}
    
    OLD COVER LETTER:
    {cover_letter_text}
    
    TASK:
    Write a customized cover letter for this specific job. 
    - Highlight specific experiences from the resume that match the job requirements.
    - Use a professional yet enticing tone.
    - Structure it properly (Header, Salutation, Body, Closing).
    """
    return await generate_content(prompt)

async def generate_notes_content(job_desc: str) -> str:
    prompt = f"""
    You are a thorough job interview researcher.
    
    JOB DESCRIPTION:
    {job_desc}
    
    TASK:
    Analyze the JD and use your internal knowledge to provide a prep document.
    Include ONLY factual info. If you do not know something, state "Not available". Do NOT hallucinate.
    
    SECTIONS REQUIRED:
    1. Main Job Responsibilities (Summarized from JD)
    2. Company Size and Founding Year
    3. Key Products/Services
    4. Target Customers
    5. Main Competitors
    6. General Reviews/Reputation (if known widely)
    7. Hiring Manager / Team Info (if found in JD)
    """
    return await generate_content(prompt)

async def extract_metadata(job_desc: str) -> dict:
    prompt = f"""
    JOB DESCRIPTION:
    {job_desc}
    
    TASK:
    Extract the COMPANY NAME and the JOB TITLE from the text above.
    Return ONLY a JSON object with keys "company" and "role".
    If not found, use "UnknownCompany" and "UnknownRole".
    Example: {{"company": "Google", "role": "Software Engineer"}}
    """
    response_text = await generate_content(prompt)
    try:
        # Clean up code blocks if present
        if "```json" in response_text:
            response_text = response_text.split("```json")[1].split("```")[0].strip()
        elif "```" in response_text:
             response_text = response_text.split("```")[1].split("```")[0].strip()
             
        data = json.loads(response_text)
        return data
    except:
        return {"company": "Company", "role": "Role"}


