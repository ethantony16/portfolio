from docx import Document
from docx.shared import RGBColor
import re
from bs4 import BeautifulSoup

def create_resume_docx(content: str, output_path: str):
    doc = Document()
    
    # Simple parser for <ins> and <del> tags
    # We will split by tags and add runs accordingly
    # This is a naive implementation; for nested tags or complex HTML it needs bs4
    
    # Using regex to find tags and text
    tokens = re.split(r'(<ins>.*?</ins>|<del>.*?</del>)', content, flags=re.DOTALL)
    
    para = doc.add_paragraph()
    
    for token in tokens:
        if token.startswith("<ins>"):
            text = token.replace("<ins>", "").replace("</ins>", "")
            run = para.add_run(text)
            run.font.color.rgb = RGBColor(0, 128, 0) # Green
        elif token.startswith("<del>"):
            text = token.replace("<del>", "").replace("</del>", "")
            run = para.add_run(text)
            run.font.color.rgb = RGBColor(255, 0, 0) # Red
            run.font.strike = False # Optional: Add strikethrough if desired, user asked for red text.
        else:
            # Normal text
            # Handle newlines?
            parts = token.split('\n')
            for i, part in enumerate(parts):
                para.add_run(part)
                if i < len(parts) - 1:
                   para = doc.add_paragraph()

    doc.save(output_path)

def create_simple_docx(content: str, output_path: str):
    doc = Document()
    # Handle markdown-like headings?
    for line in content.split('\n'):
        if line.strip().startswith('**') and line.strip().endswith('**'):
             doc.add_heading(line.strip().replace('**', ''), level=2)
        else:
             doc.add_paragraph(line)
    doc.save(output_path)
